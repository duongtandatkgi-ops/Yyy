package com.example.colorgrade;

import org.lwjgl.glfw.GLFW;

import net.minecraft.client.KeyMapping;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;

/**
 * Phím tắt của mod. Người chơi đổi phím trong Options > Controls > Key Binds > "Color Grade".
 */
public final class Keybinds {

    /** Chuỗi khoá lang cho nhóm phím (xem assets/colorgrade/lang/*.json). */
    private static final String CATEGORY = "key.categories." + ColorGradeMod.MODID;

    /** Bật/tắt bộ lọc (mặc định: G). */
    public static final KeyMapping TOGGLE =
            new KeyMapping("key." + ColorGradeMod.MODID + ".toggle", GLFW.GLFW_KEY_G, CATEGORY);

    /** Chuyển sang preset kế tiếp (mặc định: H). */
    public static final KeyMapping NEXT_PRESET =
            new KeyMapping("key." + ColorGradeMod.MODID + ".next_preset", GLFW.GLFW_KEY_H, CATEGORY);

    private Keybinds() {
    }

    /** Được gọi bởi mod bus: báo cho game biết có hai phím mới. */
    public static void onRegisterKeyMappings(RegisterKeyMappingsEvent event) {
        event.register(TOGGLE);
        event.register(NEXT_PRESET);
    }
}
