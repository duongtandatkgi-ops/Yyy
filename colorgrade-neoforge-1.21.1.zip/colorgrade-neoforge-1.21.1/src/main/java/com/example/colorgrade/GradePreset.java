package com.example.colorgrade;

import java.util.Locale;

import net.minecraft.network.chat.Component;

/**
 * Các preset (bộ thông số dựng sẵn) cho bộ lọc màu.
 *
 * <p>Thứ tự khai báo chính là thứ tự khi bấm phím "đổi preset". {@link #CUSTOM} luôn đứng cuối:
 * khi chọn CUSTOM, mod dùng các giá trị người chơi tự chỉnh trong file config (mục {@code custom}).
 */
public enum GradePreset {
    /** Không đổi màu (hữu ích để so sánh trước/sau). */
    NEUTRAL(GradeValues.NEUTRAL),

    /** Điện ảnh: tương phản cao, bớt rực, hơi ấm, tối góc nhẹ. */
    CINEMATIC(new GradeValues(-0.05f, 1.15f, 0.90f, 1.00f, 0.10f, 0.00f, 0.35f, 1.0f)),

    /** Hoàng hôn ấm: sắc cam, hơi tím nhẹ, màu đậm hơn. */
    WARM_SUNSET(new GradeValues(0.05f, 1.08f, 1.15f, 1.00f, 0.55f, 0.05f, 0.20f, 1.0f)),

    /** Đêm lạnh: tông xanh lam, hơi tối, giảm bão hoà. */
    COLD_NIGHT(new GradeValues(-0.10f, 1.10f, 0.85f, 1.05f, -0.50f, -0.05f, 0.30f, 1.0f)),

    /** Rực rỡ: bão hoà cao, tương phản tăng nhẹ. */
    VIVID(new GradeValues(0.00f, 1.12f, 1.45f, 1.00f, 0.05f, 0.00f, 0.00f, 1.0f)),

    /** Trắng đen kiểu phim noir: tương phản gắt, tối góc đậm. */
    NOIR(new GradeValues(-0.05f, 1.35f, 0.00f, 1.00f, 0.00f, 0.00f, 0.45f, 1.0f)),

    /** Sepia (ảnh cũ): gần trắng đen nhưng ngả vàng nâu. */
    SEPIA(new GradeValues(0.00f, 1.05f, 0.30f, 1.00f, 0.65f, 0.12f, 0.25f, 1.0f)),

    /** Dùng giá trị tự chỉnh trong config. Giá trị bên dưới chỉ là chỗ giữ chỗ, không được dùng. */
    CUSTOM(GradeValues.NEUTRAL);

    private final GradeValues values;

    GradePreset(GradeValues values) {
        this.values = values;
    }

    /**
     * Trả về bộ thông số thực tế cần đưa vào shader.
     * Với CUSTOM thì đọc từ config, các preset còn lại dùng hằng số dựng sẵn.
     */
    public GradeValues resolve() {
        return this == CUSTOM ? ClientConfig.customValues() : values;
    }

    /** Preset kế tiếp (quay vòng) khi bấm phím đổi preset. */
    public GradePreset next() {
        GradePreset[] all = values();
        return all[(ordinal() + 1) % all.length];
    }

    /** Tên hiển thị đã dịch (khoá lang: {@code preset.colorgrade.<tên_viết_thường>}). */
    public Component displayName() {
        return Component.translatable("preset." + ColorGradeMod.MODID + "." + name().toLowerCase(Locale.ROOT));
    }
}
