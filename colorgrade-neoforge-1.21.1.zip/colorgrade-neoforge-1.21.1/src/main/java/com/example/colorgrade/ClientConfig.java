package com.example.colorgrade;

import net.neoforged.neoforge.common.ModConfigSpec;

/**
 * Cấu hình phía client. File được tạo tại {@code .minecraft/config/colorgrade-client.toml}.
 *
 * <p>Giá trị có thể sửa bằng 3 cách: sửa file toml, qua màn hình Mods &gt; Color Grade &gt; Config
 * (NeoForge tự dựng giao diện từ spec này), hoặc dùng phím tắt trong game.
 */
public final class ClientConfig {

    private static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();

    // ---------------------------------------------------------------- Mục chính

    public static final ModConfigSpec.BooleanValue ENABLED = BUILDER
            .comment("Bat/tat bo loc mau.")
            .define("enabled", true);

    public static final ModConfigSpec.EnumValue<GradePreset> PRESET = BUILDER
            .comment("Preset dang dung. Chon CUSTOM de dung cac gia tri tu chinh o muc [custom] ben duoi.")
            .defineEnum("preset", GradePreset.CINEMATIC);

    // ---------------------------------------------------------------- Mục [custom]
    // Chỉ có tác dụng khi preset = CUSTOM.

    static {
        BUILDER.comment("Gia tri tu chinh - chi co tac dung khi preset = CUSTOM.").push("custom");
    }

    public static final ModConfigSpec.DoubleValue EXPOSURE = BUILDER
            .comment("Phoi sang (EV/stop). 0 = giu nguyen.")
            .defineInRange("exposure", 0.0, -2.0, 2.0);

    public static final ModConfigSpec.DoubleValue CONTRAST = BUILDER
            .comment("Tuong phan. 1 = giu nguyen.")
            .defineInRange("contrast", 1.0, 0.5, 2.0);

    public static final ModConfigSpec.DoubleValue SATURATION = BUILDER
            .comment("Do bao hoa. 1 = giu nguyen, 0 = trang den.")
            .defineInRange("saturation", 1.0, 0.0, 2.0);

    public static final ModConfigSpec.DoubleValue GAMMA = BUILDER
            .comment("Gamma. 1 = giu nguyen, lon hon 1 = sang hon.")
            .defineInRange("gamma", 1.0, 0.5, 2.0);

    public static final ModConfigSpec.DoubleValue TEMPERATURE = BUILDER
            .comment("Nhiet do mau. -1 = lanh (xanh), +1 = am (cam).")
            .defineInRange("temperature", 0.0, -1.0, 1.0);

    public static final ModConfigSpec.DoubleValue TINT = BUILDER
            .comment("Sac thai. -1 = ngha xanh la, +1 = ngha tim.")
            .defineInRange("tint", 0.0, -1.0, 1.0);

    public static final ModConfigSpec.DoubleValue VIGNETTE = BUILDER
            .comment("Do toi o goc man hinh. 0 = khong co.")
            .defineInRange("vignette", 0.0, 0.0, 1.0);

    public static final ModConfigSpec.DoubleValue STRENGTH = BUILDER
            .comment("Muc ap dung bo loc. 0 = anh goc, 1 = ap dung hoan toan.")
            .defineInRange("strength", 1.0, 0.0, 1.0);

    static {
        BUILDER.pop();
    }

    /** Spec hoàn chỉnh - được đăng ký với NeoForge trong constructor của mod. */
    public static final ModConfigSpec SPEC = BUILDER.build();

    private ClientConfig() {
    }

    /** Gom các giá trị trong mục [custom] thành một {@link GradeValues}. */
    public static GradeValues customValues() {
        return new GradeValues(
                EXPOSURE.get().floatValue(),
                CONTRAST.get().floatValue(),
                SATURATION.get().floatValue(),
                GAMMA.get().floatValue(),
                TEMPERATURE.get().floatValue(),
                TINT.get().floatValue(),
                VIGNETTE.get().floatValue(),
                STRENGTH.get().floatValue()
        );
    }
}
