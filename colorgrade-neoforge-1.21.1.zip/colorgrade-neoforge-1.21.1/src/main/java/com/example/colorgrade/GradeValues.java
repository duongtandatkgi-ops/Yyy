package com.example.colorgrade;

/**
 * Bộ 8 thông số của bộ lọc màu. Mỗi thông số tương ứng với một uniform cùng tên (viết hoa chữ đầu)
 * trong shader {@code assets/colorgrade/shaders/program/color_grade.fsh}.
 *
 * <p>Dùng {@code record} để bất biến và gọn: mỗi lần đổi preset chỉ cần trỏ sang một đối tượng khác.
 *
 * @param exposure    Phơi sáng theo đơn vị "stop" (EV). 0 = giữ nguyên, +1 = sáng gấp đôi, -1 = tối một nửa.
 * @param contrast    Tương phản quanh mức xám trung bình. 1 = giữ nguyên, &gt;1 = gắt hơn, &lt;1 = phẳng hơn.
 * @param saturation  Độ bão hoà màu. 1 = giữ nguyên, 0 = trắng đen, &gt;1 = rực hơn.
 * @param gamma       Gamma. 1 = giữ nguyên, &gt;1 = sáng vùng tối/trung tính, &lt;1 = tối hơn.
 * @param temperature Nhiệt độ màu. -1 = lạnh (xanh), 0 = giữ nguyên, +1 = ấm (cam).
 * @param tint        Sắc thái xanh lá/tím. -1 = ngả xanh lá, 0 = giữ nguyên, +1 = ngả tím (magenta).
 * @param vignette    Độ tối ở góc màn hình. 0 = không có, 1 = rất đậm.
 * @param strength    Mức áp dụng bộ lọc. 0 = ảnh gốc, 1 = áp dụng hoàn toàn (trộn tuyến tính).
 */
public record GradeValues(
        float exposure,
        float contrast,
        float saturation,
        float gamma,
        float temperature,
        float tint,
        float vignette,
        float strength
) {
    /** Giá trị "trung tính": bộ lọc không làm thay đổi hình ảnh. */
    public static final GradeValues NEUTRAL = new GradeValues(0f, 1f, 1f, 1f, 0f, 0f, 0f, 1f);
}
