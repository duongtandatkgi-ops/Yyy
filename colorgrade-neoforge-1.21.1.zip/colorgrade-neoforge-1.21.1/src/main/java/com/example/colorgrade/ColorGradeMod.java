package com.example.colorgrade;

import org.slf4j.Logger;

import com.mojang.logging.LogUtils;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;
import net.neoforged.neoforge.common.NeoForge;

/**
 * Lớp chính của mod - nơi FML (bộ nạp mod của NeoForge) gọi đầu tiên.
 *
 * <p>{@code dist = Dist.CLIENT}: mod chỉ được nạp trên client. Trên dedicated server lớp này bị bỏ qua,
 * nên bên dưới ta có thể tham chiếu trực tiếp các lớp client (Minecraft, KeyMapping...) mà không lo crash.
 *
 * <p>Giá trị {@link #MODID} phải khớp với {@code mod_id} trong gradle.properties.
 */
@Mod(value = ColorGradeMod.MODID, dist = Dist.CLIENT)
public class ColorGradeMod {

    public static final String MODID = "colorgrade";
    public static final Logger LOGGER = LogUtils.getLogger();

    /**
     * FML tự truyền {@link IEventBus} (bus sự kiện của mod) và {@link ModContainer} vào constructor.
     */
    public ColorGradeMod(IEventBus modEventBus, ModContainer container) {
        // 1) Đăng ký file config client -> tạo config/colorgrade-client.toml
        container.registerConfig(ModConfig.Type.CLIENT, ClientConfig.SPEC);

        // 2) Cho NeoForge tự dựng màn hình cấu hình (Mods > Color Grade > Config) từ ClientConfig.SPEC
        container.registerExtensionPoint(IConfigScreenFactory.class, ConfigurationScreen::new);

        // 3) Sự kiện của mod bus: đăng ký phím tắt và listener nạp lại tài nguyên
        modEventBus.addListener(Keybinds::onRegisterKeyMappings);
        modEventBus.addListener(GradeController::onRegisterReloadListeners);

        // 4) Sự kiện của game bus: mỗi tick client, đồng bộ hiệu ứng với config
        NeoForge.EVENT_BUS.addListener(GradeController::onClientTick);
    }
}
