package com.example.colorgrade;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterClientReloadListenersEvent;

/**
 * Bộ điều khiển hiệu ứng: nạp/gỡ "post effect" của mod và đẩy thông số vào shader.
 *
 * <h2>Cách hoạt động (tóm tắt)</h2>
 * Vanilla có sẵn hệ thống "post effect": một file JSON mô tả chuỗi lượt vẽ toàn màn hình (pass).
 * {@link GameRenderer} giữ một {@link PostChain} duy nhất và chạy nó mỗi frame
 * SAU khi thế giới + tay đã vẽ xong nhưng TRƯỚC khi vẽ GUI. Vì vậy bộ lọc màu chỉ ảnh hưởng
 * hình ảnh trong thế giới, không làm đổi màu HUD/menu.
 *
 * <p>Việc của lớp này:
 * <ol>
 *   <li>Mỗi tick: nếu bộ lọc đang bật mà chưa được nạp thì nạp {@code colorgrade:shaders/post/color_grade.json}.</li>
 *   <li>Mỗi tick: đẩy 8 thông số của preset hiện tại vào các uniform của shader.</li>
 *   <li>Nếu bị tắt thì gỡ hiệu ứng của mình ra.</li>
 *   <li>Không giành quyền với vanilla: khi đang có hiệu ứng khác (ví dụ spectate Creeper) thì để yên.</li>
 * </ol>
 */
public final class GradeController {

    /** Đường dẫn đầy đủ tới file post-chain: assets/colorgrade/shaders/post/color_grade.json */
    private static final ResourceLocation POST_CHAIN =
            ResourceLocation.fromNamespaceAndPath(ColorGradeMod.MODID, "shaders/post/color_grade.json");

    /**
     * Thể hiện PostChain do mod này nạp. Dùng để phân biệt "hiệu ứng của mình" với hiệu ứng vanilla
     * (vanilla có thể tự đóng/thay thế PostChain bất cứ lúc nào, ví dụ khi đổi camera entity).
     */
    private static PostChain ours; // null = chưa có / đã bị vanilla gỡ

    /** Nạp thất bại (shader lỗi...) -> ngừng thử lại mỗi tick để khỏi spam log. */
    private static boolean loadFailed = false;

    /** Có yêu cầu nạp lại từ đầu (sau khi reload tài nguyên F3+T / đổi resource pack). */
    private static boolean reloadRequested = false;

    private GradeController() {
    }

    // =============================================================================================
    //  Đăng ký sự kiện
    // =============================================================================================

    /** Mod bus: đăng ký listener được gọi mỗi khi tài nguyên được nạp lại. */
    public static void onRegisterReloadListeners(RegisterClientReloadListenersEvent event) {
        event.registerReloadListener((ResourceManagerReloadListener) manager -> {
            // Reload tài nguyên làm shader cũ mất hiệu lực -> đánh dấu để tick sau nạp lại sạch sẽ.
            reloadRequested = true;
            loadFailed = false;
        });
    }

    /** Game bus: chạy sau mỗi tick của client (20 lần/giây). */
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        handleKeys(mc);
        syncEffect(mc);
    }

    // =============================================================================================
    //  Phím tắt
    // =============================================================================================

    private static void handleKeys(Minecraft mc) {
        // consumeClick() trả true một lần cho mỗi lần bấm; dùng while để không bỏ sót khi bấm nhanh.
        while (Keybinds.TOGGLE.consumeClick()) {
            boolean now = !ClientConfig.ENABLED.get();
            ClientConfig.ENABLED.set(now);
            ClientConfig.SPEC.save(); // ghi xuống file toml để lần sau vào game vẫn giữ
            loadFailed = false;
            showMessage(mc, Component.translatable(now ? "message.colorgrade.enabled" : "message.colorgrade.disabled"));
        }

        while (Keybinds.NEXT_PRESET.consumeClick()) {
            GradePreset next = ClientConfig.PRESET.get().next();
            ClientConfig.PRESET.set(next);
            // Bấm đổi preset khi đang tắt thì tự bật lên cho người chơi thấy ngay kết quả.
            ClientConfig.ENABLED.set(true);
            ClientConfig.SPEC.save();
            loadFailed = false;
            showMessage(mc, Component.translatable("message.colorgrade.preset", next.displayName()));
        }
    }

    /** Hiện thông báo ngắn trên thanh action bar (phía trên hotbar). */
    private static void showMessage(Minecraft mc, Component message) {
        if (mc.player != null) {
            mc.player.displayClientMessage(message, true);
        }
    }

    // =============================================================================================
    //  Đồng bộ hiệu ứng với config
    // =============================================================================================

    private static void syncEffect(Minecraft mc) {
        // Post effect chỉ được vẽ khi đang ở trong thế giới; ngoài thế giới không cần làm gì.
        if (mc.level == null) {
            return;
        }

        GameRenderer renderer = mc.gameRenderer;
        PostChain current = renderer.currentEffect();

        // Xử lý yêu cầu nạp lại: gỡ hiệu ứng cũ của mình (nếu còn) để nạp lại shader mới.
        if (reloadRequested) {
            reloadRequested = false;
            if (current != null && current == ours) {
                renderer.shutdownEffect();
                current = null;
            }
            ours = null;
        }

        // Có hiệu ứng khác (không phải của mình) đang chạy, ví dụ spectate Creeper -> nhường vanilla.
        if (current != null && current != ours) {
            ours = null;
            return;
        }

        if (!ClientConfig.ENABLED.get()) {
            // Đang tắt: nếu hiệu ứng của mình còn chạy thì gỡ ra.
            if (current != null) {
                renderer.shutdownEffect();
            }
            ours = null;
            return;
        }

        if (current == null) {
            if (loadFailed) {
                return;
            }
            // loadEffect vốn là hàm private của vanilla; mod mở quyền bằng accesstransformer.cfg.
            renderer.loadEffect(POST_CHAIN);
            current = renderer.currentEffect();
            if (current == null) {
                // loadEffect tự bắt lỗi (JSON/GLSL sai) và để postEffect = null.
                loadFailed = true;
                ColorGradeMod.LOGGER.error("Khong nap duoc post effect {} - xem log phia tren de biet loi shader.", POST_CHAIN);
                return;
            }
            ours = current;
        }

        applyUniforms(current, ClientConfig.PRESET.get().resolve());
    }

    /**
     * Đẩy thông số vào shader. {@link PostChain#setUniform(String, float)} gán giá trị cho uniform
     * cùng tên ở mọi pass của chain; pass nào không khai báo uniform đó sẽ bỏ qua.
     * Mọi uniform đều là float đơn để dùng được hàm này.
     */
    private static void applyUniforms(PostChain chain, GradeValues v) {
        chain.setUniform("Exposure", v.exposure());
        chain.setUniform("Contrast", v.contrast());
        chain.setUniform("Saturation", v.saturation());
        chain.setUniform("Gamma", v.gamma());
        chain.setUniform("Temperature", v.temperature());
        chain.setUniform("Tint", v.tint());
        chain.setUniform("Vignette", v.vignette());
        chain.setUniform("Strength", v.strength());
    }
}
