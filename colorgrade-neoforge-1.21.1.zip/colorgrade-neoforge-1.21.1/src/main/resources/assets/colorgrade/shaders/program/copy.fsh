#version 150

// Pass chep don gian: dua ket qua tu buffer tam "swap" ve framebuffer chinh cua game.

uniform sampler2D DiffuseSampler;

in vec2 texCoord;
out vec4 fragColor;

void main() {
    fragColor = vec4(texture(DiffuseSampler, texCoord).rgb, 1.0);
}
