#version 150

// Fragment shader chinh: color grading. (Chu thich dung ASCII khong dau vi ly do tuong thich driver.)
//
// Khong the vua doc vua ghi cung mot texture, nen pass nay doc tu framebuffer chinh
// (DiffuseSampler) va ghi ra buffer tam "swap"; pass "copy" sau do chep "swap" nguoc ve
// framebuffer chinh.
//
// Framebuffer cua Minecraft da o khong gian mau sRGB/gamma nen ta chinh truc tiep tren do
// (cach lam don gian, du cho mot bo loc mau tham my).

uniform sampler2D DiffuseSampler;
uniform vec2 OutSize;

// Cac thong so - mod gan moi tick tu preset/config (xem GradeController.applyUniforms)
uniform float Exposure;     // EV/stop: 0 = giu nguyen
uniform float Contrast;     // 1 = giu nguyen
uniform float Saturation;   // 1 = giu nguyen, 0 = trang den
uniform float Gamma;        // 1 = giu nguyen, >1 = sang hon
uniform float Temperature;  // -1 lanh ... +1 am
uniform float Tint;         // -1 xanh la ... +1 tim
uniform float Vignette;     // 0 = khong toi goc
uniform float Strength;     // 0 = anh goc ... 1 = ap dung hoan toan

in vec2 texCoord;
out vec4 fragColor;

// Trong so do sang cam nhan duoc (Rec.709)
const vec3 LUMA = vec3(0.2126, 0.7152, 0.0722);

void main() {
    vec3 original = texture(DiffuseSampler, texCoord).rgb;
    vec3 c = original;

    // 1) Phoi sang: nhan 2^EV
    c *= exp2(Exposure);

    // 2) Can bang trang: nhiet do am -> tang do, giam lam; tint tim -> giam luc
    c *= vec3(1.0 + 0.30 * Temperature,
              1.0 - 0.20 * Tint,
              1.0 - 0.30 * Temperature);

    // 3) Tuong phan quanh muc xam trung binh 0.5
    c = (c - 0.5) * Contrast + 0.5;

    // 4) Do bao hoa: tron giua anh trang den (luma) va anh mau
    float luma = dot(c, LUMA);
    c = mix(vec3(luma), c, Saturation);

    // 5) Gamma (max de tranh pow voi so am sau buoc tuong phan)
    c = pow(max(c, vec3(0.0)), vec3(1.0 / max(Gamma, 0.01)));

    // 6) Vignette: toi dan ve phia goc. p duoc hieu chinh theo ti le khung hinh
    //    de vung toi tron deu.
    vec2 p = (texCoord - 0.5) * vec2(OutSize.x / OutSize.y, 1.0);
    float vig = 1.0 - smoothstep(0.35, 1.05, length(p));
    c *= mix(1.0, vig, Vignette);

    // 7) Gioi han ve [0,1] roi tron voi anh goc theo Strength
    c = clamp(c, 0.0, 1.0);
    fragColor = vec4(mix(original, c, Strength), 1.0);
}
