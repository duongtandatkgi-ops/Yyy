#version 150

// LUU Y: file shader chi nen dung ky tu ASCII (khong dau), vi mot so driver do hoa
// bao loi khi gap ky tu UTF-8 ngay ca trong chu thich.
//
// Vertex shader dung chung cho ca hai pass (color_grade va copy).
// He thong post-effect cua vanilla ve mot hinh chu nhat co kich thuoc = OutSize (pixel),
// ProjMat la ma tran truc giao, nen toa do texture chinh la Position / OutSize.

in vec4 Position;

uniform mat4 ProjMat;
uniform vec2 OutSize;

out vec2 texCoord;

void main() {
    vec4 outPos = ProjMat * vec4(Position.xy, 0.0, 1.0);
    gl_Position = vec4(outPos.xy, 0.2, 1.0);
    texCoord = Position.xy / OutSize;
}
