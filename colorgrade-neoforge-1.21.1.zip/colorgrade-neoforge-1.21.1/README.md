# Color Grade — mod bộ lọc màu cho Minecraft 1.21.1 (NeoForge)

Mod client-side thêm bộ lọc màu (color grading) bằng post-processing shader: phơi sáng, tương phản,
độ bão hoà, gamma, nhiệt độ màu, sắc thái, vignette, cùng 7 preset dựng sẵn
(Neutral, Cinematic, Warm Sunset, Cold Night, Vivid, Noir, Sepia) và một preset Custom tự chỉnh.

- Phím **G**: bật/tắt bộ lọc. Phím **H**: đổi preset (đổi phím trong Options > Controls).
- Cấu hình: Mods > Color Grade > Config, hoặc file `config/colorgrade-client.toml`.
- Bộ lọc chỉ tác động lên hình ảnh trong thế giới (gồm cả tay), **không** làm đổi màu HUD/menu.

## Yêu cầu

| Thành phần | Phiên bản |
|---|---|
| Minecraft Java Edition | 1.21.1 |
| NeoForge | 21.1.x (project build với 21.1.248) |
| JDK để build | 21 |
| Gradle | 9.2.1 (qua Gradle Wrapper) |

## Cấu trúc thư mục

```
colorgrade-neoforge-1.21.1/
├── build.gradle                  # Cấu hình build (ModDevGradle)
├── gradle.properties             # Phiên bản + thông tin mod (mod_id, version...)
├── settings.gradle
├── gradle/wrapper/gradle-wrapper.properties
└── src/main/
    ├── templates/META-INF/neoforge.mods.toml     # Metadata mod (Gradle điền biến ${...})
    ├── java/com/example/colorgrade/
    │   ├── ColorGradeMod.java     # Lớp @Mod chính: đăng ký config, phím, sự kiện
    │   ├── GradeController.java   # Nạp/gỡ post effect + đẩy thông số vào shader
    │   ├── GradePreset.java       # Các preset
    │   ├── GradeValues.java       # 8 thông số của bộ lọc
    │   ├── ClientConfig.java      # Config (ModConfigSpec)
    │   └── Keybinds.java          # Phím tắt
    └── resources/
        ├── META-INF/accesstransformer.cfg        # Mở quyền gọi GameRenderer#loadEffect
        └── assets/colorgrade/
            ├── lang/en_us.json, vi_vn.json
            └── shaders/
                ├── post/color_grade.json         # Chuỗi pass: color_grade -> copy
                └── program/                      # Shader GLSL (vsh/fsh) + định nghĩa program
```

## Build ra file .jar — từng bước

### Bước 1: Cài JDK 21
Tải Temurin 21 (adoptium.net) hoặc dùng JDK 21 bất kỳ. Kiểm tra: `java -version` phải hiện 21.x.
(Nếu máy chưa có, plugin foojay trong `settings.gradle` sẽ tự tải JDK 21 khi build.)

### Bước 2: Lấy Gradle Wrapper
Zip này không kèm `gradlew`, `gradlew.bat` và `gradle-wrapper.jar` (file nhị phân). Chọn một trong hai cách:

**Cách A (khuyến nghị):**
1. Vào https://github.com/NeoForgeMDKs/MDK-1.21.1-ModDevGradle, bấm *Code > Download ZIP*, giải nén.
2. Chép toàn bộ nội dung project này (thư mục `src/`, `build.gradle`, `gradle.properties`, `settings.gradle`,
   `.gitignore`) đè lên thư mục MDK vừa giải nén. **Xoá thư mục `src/main/java/com/example/examplemod`
   và các file mẫu của MDK** (ví dụ `Config.java`, `ExampleMod.java`, `examplemod.mixins.json`
   nếu có) để không bị trùng.

**Cách B:** cài Gradle 9.2.1 rồi chạy `gradle wrapper` trong thư mục project này.

### Bước 3: Build
Mở terminal tại thư mục project:

```bash
# Linux / macOS
chmod +x gradlew
./gradlew build

# Windows (PowerShell hoặc CMD)
gradlew.bat build
```

Lần đầu mất vài phút đến hơn chục phút (tải Gradle, Minecraft, NeoForge, decompile). Các lần sau nhanh hơn nhiều.
Cần có internet.

### Bước 4: Lấy file .jar
Thành phẩm nằm ở:

```
build/libs/colorgrade-1.0.0.jar
```

(Tên = `mod_id` + `mod_version` trong `gradle.properties`.) Đây là file duy nhất cần dùng.
Nếu thấy thêm file `-sources.jar` thì bỏ qua nó.

### Bước 5: Cài vào game
1. Cài NeoForge 21.1.x cho Minecraft 1.21.1 (neoforged.net).
2. Chép `colorgrade-1.0.0.jar` vào thư mục `.minecraft/mods/`.
3. Chạy profile NeoForge, vào thế giới, bấm **G** / **H**.

### Chạy thử ngay trong môi trường dev (không cần cài NeoForge)
```bash
./gradlew runClient
```

## Cách mod hoạt động (tóm tắt)

1. Vanilla có hệ thống *post effect*: file JSON mô tả các pass shader toàn màn hình. `GameRenderer` chạy chuỗi
   này mỗi frame sau khi vẽ thế giới và tay, trước khi vẽ GUI.
2. `GradeController` nạp `colorgrade:shaders/post/color_grade.json` bằng `GameRenderer#loadEffect`
   (private, được mở quyền bằng Access Transformer) và đẩy 8 thông số vào uniform của shader mỗi tick.
3. Chuỗi gồm 2 pass vì không thể đọc và ghi cùng một texture: `color_grade` (framebuffer chính -> buffer tạm)
   rồi `copy` (buffer tạm -> framebuffer chính).
4. Mod không giành quyền với vanilla: nếu có hiệu ứng khác đang chạy (ví dụ spectate Creeper) thì nhường.

## Tuỳ chỉnh nhanh

- **Đổi tên/mod id/package:** sửa `mod_id`, `mod_group_id` trong `gradle.properties`, hằng `MODID` trong
  `ColorGradeMod.java`, thư mục `assets/colorgrade` và package Java cho khớp.
- **Thêm preset:** thêm một dòng vào `GradePreset.java` (và khoá dịch `preset.colorgrade.<tên>` trong file lang).
- **Sửa công thức màu:** chỉnh `color_grade.fsh`. Giữ comment trong file shader ở dạng ASCII (không dấu)
  vì một số driver đồ hoạ báo lỗi khi gặp ký tự UTF-8.

## Xử lý sự cố

| Triệu chứng | Cách xử lý |
|---|---|
| `Unsupported class file major version` / lỗi Java | Đang dùng JDK khác 21. Kiểm tra `java -version`, đặt `JAVA_HOME` trỏ JDK 21. |
| Lỗi Access Transformer / không tìm thấy `loadEffect` | Bạn đang build với Minecraft/NeoForge khác 1.21.1. Giữ `neo_version=21.1.x`. |
| Không thấy hiệu ứng trong game | Xem `logs/latest.log` tìm dòng `Khong nap duoc post effect`; kiểm tra có đang dùng shader pack (Iris/Oculus) không. |
| Hết bộ nhớ khi build | Tăng `org.gradle.jvmargs=-Xmx2G` lên `-Xmx3G` trong `gradle.properties`. |
| Muốn cập nhật NeoForge | Đổi `neo_version` (xem https://projects.neoforged.net/neoforged/neoforge, chọn dòng 21.1.x). |

## Lưu ý tương thích

- Chỉ dành cho **Minecraft 1.21.1**. Từ 1.21.2 trở đi hệ thống post effect của vanilla được viết lại
  (định dạng JSON khác), nên mã và shader phải làm lại.
- Mod dùng hệ thống post effect của vanilla; khi dùng shader pack qua Iris/Oculus, pack sẽ tự quản lý
  hậu kỳ và bộ lọc này có thể không hiển thị hoặc xung đột.
- Mod là client-side: cài vào client là đủ, không cần cài lên server.
